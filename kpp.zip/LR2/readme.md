# Лабораторна 2: Розробка браузерної аплікації

## Quickstart
``` bash
npm install
npm start
```

##Example of work
![example of work](https://github.com/alinamazur01/kpp/blob/master/LR2/photo_2020-04-08_12-18-14.jpg)
