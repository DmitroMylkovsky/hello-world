## KPP
#Lab1

Results of testing

![lb1_res](https://github.com/alinamazur01/kpp/blob/master/lb1_res.PNG)
